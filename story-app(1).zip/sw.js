self.addEventListener('install', (e) => {
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(self.clients.claim());
});

// Handle incoming push notifications
self.addEventListener('push', (event) => {
  let payload = {};
  try { payload = event.data?.json?.() || JSON.parse(event.data?.text?.() || '{}'); } catch (e) {}
  const title = payload?.title || 'Notifikasi Story';
  const options = payload?.options || { body: 'Ada pembaruan.' };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(self.clients.openWindow?.('#/'));
});


