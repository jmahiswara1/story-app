export async function withViewTransition(root, renderFn) {
  // Prefer native View Transitions when available; don't block on finish
  if (typeof document.startViewTransition === "function") {
    try {
      document.startViewTransition(() => renderFn());
      return; // don't await; allow content to render immediately
    } catch (_) {
      // fall through to CSS fallback
    }
  }

  // CSS fallback: do not keep UI invisible while async render runs
  root.setAttribute("data-view-transition", "");
  root.classList.remove("in");
  root.classList.add("out");
  await new Promise((r) => setTimeout(r, 60));
  const maybePromise = renderFn(); // kick off render without waiting fully
  root.classList.remove("out");
  root.classList.add("in");
  if (maybePromise && typeof maybePromise.then === "function") {
    try {
      await maybePromise;
    } catch (_) {}
  }
}
