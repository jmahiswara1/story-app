import { initRouter, navigateTo } from './router.js';
import './app.css';
import { createHeader } from './modules/components/Header.js';
import { Storage } from './modules/utils/storage.js';

// Register service worker for push notifications (non-blocking)
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('./sw.js').catch(() => {});
}

const headerRoot = document.getElementById('header');
const mainRoot = document.getElementById('main');

function mountHeader() {
  headerRoot.innerHTML = '';
  headerRoot.append(
    createHeader({
      isAuthenticated: !!Storage.getToken(),
      onNavigate: (hash) => navigateTo(hash),
      onLogout: () => {
        Storage.clear();
        navigateTo('#/login');
      },
    }),
  );
}

// Initialize App
mountHeader();
initRouter({ onRoute: mountHeader, mainRoot });


