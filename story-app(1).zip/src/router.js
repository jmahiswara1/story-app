import { withViewTransition } from './modules/utils/viewTransition.js';
import { Storage } from './modules/utils/storage.js';

import { LoginView } from './modules/views/LoginView.js';
import { RegisterView } from './modules/views/RegisterView.js';
import { HomeView } from './modules/views/HomeView.js';
import { AddStoryView } from './modules/views/AddStoryView.js';
import { DetailView } from './modules/views/DetailView.js';
import { NotFoundView } from './modules/views/NotFoundView.js';

const routes = [
  { path: '#/', private: true, view: HomeView },
  { path: '#/login', view: LoginView },
  { path: '#/register', view: RegisterView },
  { path: '#/add', private: true, view: AddStoryView },
  { path: '#/detail/:id', private: true, view: DetailView },
];

function parseLocation() {
  const hash = window.location.hash || '#/';
  return hash;
}

function matchRoute(hash) {
  for (const r of routes) {
    if (r.path.includes(':')) {
      const base = r.path.split('/:')[0];
      if (hash.startsWith(base + '/')) return { route: r, params: { id: hash.split('/').pop() } };
    } else if (r.path === hash) return { route: r, params: {} };
  }
  return { route: null, params: {} };
}

export function navigateTo(hash) {
  if (window.location.hash === hash) return window.dispatchEvent(new HashChangeEvent('hashchange'));
  window.location.hash = hash;
}

export function initRouter({ onRoute, mainRoot }) {
  async function render() {
    const hash = parseLocation();
    const { route, params } = matchRoute(hash);

    if (!route) return withViewTransition(mainRoot, () => NotFoundView({ mainRoot }));

    if (route.private && !Storage.getToken()) {
      return navigateTo('#/login');
    }

    await withViewTransition(mainRoot, () => route.view({ params, mainRoot }));
    if (typeof onRoute === 'function') onRoute();
  }

  window.addEventListener('hashchange', render);
  window.addEventListener('DOMContentLoaded', render);
  render();
}


